package com.marketprice.task.service;

import com.marketprice.task.bean.MarketPriceBean;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SpringBootTest
public class MarketPriceListnerServiceTest {
    @Autowired
    MarketPriceListnerService marketPriceListnerService;

    @Test
    public void testPriceUpdateGivenListPrice()
    {
        List<MarketPriceBean> priceListOutput= new ArrayList<>();
        List<MarketPriceBean> priceListInput= new ArrayList<>();
        MarketPriceBean marketPriceBean= new MarketPriceBean();
        marketPriceBean.setId(100);
        marketPriceBean.setBid(1.0000);
        marketPriceBean.setAsk(10.0000);
        marketPriceBean.setCurrencies("GBP/LES");
        marketPriceBean.setCurrencies(String.valueOf(new Date()));
        priceListInput.add(marketPriceBean);
        priceListOutput=marketPriceListnerService.getUpdatedPrice(priceListInput);
        Assertions.assertEquals(0.999,priceListOutput.get(0).getBid());
        Assertions.assertEquals(10.01,priceListOutput.get(0).getAsk());
    }

}
