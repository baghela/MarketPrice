package com.marketprice.task.subscriber;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MarketPriceListnerSubscriberTest {
    @Autowired
    MarketPriceSubscriber marketPriceSubscriber;

    @Test
    public void testMessageProcessing()
    {
        marketPriceSubscriber.onMessage("106, EUR/USD, 1.1000,1.2000,01-06-2020 12:01:01:001");
        Assertions.assertEquals(1,marketPriceSubscriber.updatedPrice.size());
    }
}
