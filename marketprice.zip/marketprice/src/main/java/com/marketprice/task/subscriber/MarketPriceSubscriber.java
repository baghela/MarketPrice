package com.marketprice.task.subscriber;

import com.marketprice.task.bean.MarketPriceBean;
import com.marketprice.task.constants.ApplicationConstant;
import com.marketprice.task.service.MarketPriceListnerService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 This class listen the message received and parse the message into bean and call for processing .
 This is assumed that we will call a method onMessage with String parameter .
 */
@Service
@Log4j2
public class MarketPriceSubscriber {


    public List<MarketPriceBean> updatedPrice=new ArrayList<>();
   @Autowired
    MarketPriceListnerService marketPriceListnerService;

    public  void onMessage(String message) {
        List<MarketPriceBean> receivedPrices = new ArrayList<>();

        String[] receivedPrice = message.split(ApplicationConstant.LINE_SEPARATOR);
        for (int i = 0; i < receivedPrice.length; i++) {
            MarketPriceBean receiveParams = new MarketPriceBean();
            receiveParams.setId(Integer.parseInt(receivedPrice[i].split(ApplicationConstant.CSV_DELIMITER)[0].trim()));
            receiveParams.setCurrencies(receivedPrice[i].split(ApplicationConstant.CSV_DELIMITER)[1].trim());
            receiveParams.setBid(Double.valueOf(receivedPrice[i].split(ApplicationConstant.CSV_DELIMITER)[2].trim()));
            receiveParams.setAsk(Double.valueOf(receivedPrice[i].split(ApplicationConstant.CSV_DELIMITER)[3].trim()));
            receiveParams.setTimeStamp(receivedPrice[i].split(ApplicationConstant.CSV_DELIMITER)[4].trim());
            receivedPrices.add(receiveParams);
        }
        updatedPrice.addAll(marketPriceListnerService.getUpdatedPrice(receivedPrices));
    }
}




