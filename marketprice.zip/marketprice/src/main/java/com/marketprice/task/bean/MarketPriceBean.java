package com.marketprice.task.bean;

import lombok.*;

import java.util.Objects;

/**This class hold the attributes of incoming messages . These are in order received in message .
**/

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MarketPriceBean {
    private int id;
    private String currencies;
    private Double bid;
    private Double ask;
    private String timeStamp;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MarketPriceBean that)) return false;
        return currencies.equals(that.currencies);
    }

    @Override
    public int hashCode() {
        return Objects.hash(currencies);
    }

    public MarketPriceBean(MarketPriceBean m) {
        this.id=m.getId();
        this.currencies=m.getCurrencies();
        this.bid=m.getBid();
        this.ask=m.getAsk();
        this.timeStamp=m.getTimeStamp();
    }


}
