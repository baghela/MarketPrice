package com.marketprice.task.service;

import com.marketprice.task.bean.MarketPriceBean;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * This is service class which updated the prices by applying margin -0.1% on Bid and
 * +0.1% on ask.
 */
@Service
public class MarketPriceListnerService {


    public  List<MarketPriceBean> getUpdatedPrice(List<MarketPriceBean> receivedPrice)
    {
        return receivedPrice.stream().map(m ->
        {
            MarketPriceBean updatedBean= new MarketPriceBean(m);
            updatedBean.setBid(m.getBid()-0.001*m.getBid());
            updatedBean.setAsk(m.getAsk()+0.001*m.getAsk());
            return updatedBean;
        }).collect(Collectors.toList());

    }
}
