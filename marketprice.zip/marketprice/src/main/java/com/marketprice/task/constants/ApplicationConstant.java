package com.marketprice.task.constants;

public class ApplicationConstant {

    public final static String CSV_DELIMITER=",";
    public final static String LINE_SEPARATOR="\n";

}
