package com.marketprice.task.controller;

import com.marketprice.task.bean.MarketPriceBean;
import com.marketprice.task.subscriber.MarketPriceSubscriber;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

/**
 * This is Controller class to send the updated data to the other team which will use it to get the latest price.
 */

@RestController
public class MarketPriceController {

    @Autowired
     MarketPriceSubscriber marketPriceSubscriber;






    @GetMapping("/updatedprice/")
    public List<MarketPriceBean> getUpdatedPrice()
    {
         return marketPriceSubscriber.updatedPrice;
    }
    @GetMapping("/updatedprice/{currency}")
    public List<MarketPriceBean> getUpdatedPrice(@PathVariable String currency)
    {
        return marketPriceSubscriber.updatedPrice.stream().filter(m->m.getCurrencies().equalsIgnoreCase(currency)).
                collect(Collectors.toList());
    }

}
