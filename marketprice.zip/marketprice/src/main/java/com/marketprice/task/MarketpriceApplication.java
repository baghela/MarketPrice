package com.marketprice.task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketpriceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarketpriceApplication.class, args);
	}

}
